const firebaseConfig = {
    apiKey: "AIzaSyA5MT1u123r3160KpPpSctY_HicacKC524",
    authDomain: "abcd-aece1.firebaseapp.com",
    projectId: "abcd-aece1",
    storageBucket: "abcd-aece1.appspot.com",
    messagingSenderId: "944385870751",
    appId: "1:944385870751:web:94ec638a54ebbab8498baa",
    measurementId: "G-G1MMKTWLMG"
  };
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();